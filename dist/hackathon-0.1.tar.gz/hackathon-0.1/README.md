# mypackage
This library was created .

## building this package locally
`python setup.py sdist`

## installing this packages from GitHub
`pip install git+http://github.com/James-Leslie/example-python-packages.git`

## updating this package from GitHub
`pip install --upgrade git+https://github.com/James-Leslie/example-python-package.git`
